import http.client
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

R=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('sagaz_test_app',R/'sagaz/app.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)

class SagaZTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.server=m.Server(('127.0.0.1',0),Path(self.temp.name))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.host=f'127.0.0.1:{self.server.server_port}';self.cookie=''
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join();self.temp.cleanup()
    def request(self,method,path,body=None,headers=None):
        conn=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5)
        conn.request(method,path,body=body,headers=headers or {});r=conn.getresponse();content=r.read();h=dict(r.getheaders());status=r.status;conn.close();return status,h,content
    def login(self):
        status,h,b=self.request('GET','/');self.assertEqual(status,200)
        self.assertIn(b'SAGAZ',b);self.cookie=h['Set-Cookie'].split(';')[0]
    def test_local_chat_exports_real_context_without_model(self):
        self.login()
        headers={'Cookie':self.cookie,'Content-Type':'application/json','Origin':'http://'+self.host}
        with patch.object(m.CORE,'run') as remote:
            status,h,b=self.request('POST','/api/chat',json.dumps({'brief':'Campanha RR sobre painel apagado','niche':'automotive'}),headers)
            self.assertEqual(status,200);remote.assert_not_called()
        d=json.loads(b);self.assertEqual(d['mode'],'local_preparation')
        status,h,b=self.request('GET','/api/context/'+d['id']);self.assertEqual(status,200);self.assertIn('Campanha RR',b.decode())
        status,h,b=self.request('GET','/api/projects');self.assertEqual(len(json.loads(b)),1)
    def test_csrf_host_and_invalid_scope(self):
        body=json.dumps({'brief':'Teste'})
        status,_,_=self.request('POST','/api/chat',body,{'Content-Type':'application/json'});self.assertEqual(status,403)
        self.login()
        headers={'Cookie':self.cookie,'Content-Type':'application/json','Origin':'https://example.invalid'}
        status,_,_=self.request('POST','/api/chat',body,headers);self.assertEqual(status,403)
        status,_,_=self.request('GET','/api/status',headers={'Host':'evil.invalid'});self.assertEqual(status,421)
        headers['Origin']='http://'+self.host
        status,_,_=self.request('POST','/api/chat',json.dumps({'brief':'x','niche':'invalid'}),headers);self.assertEqual(status,400)
    def test_private_configuration_and_path_boundaries(self):
        with patch.dict(m.os.environ,{'DSANT_API_KEY':'secret-test-value','DSANT_BASE_URL':'https://example.invalid/v1','DSANT_MODEL':'test'}):
            status,_,body=self.request('GET','/api/status');self.assertEqual(status,200);self.assertNotIn(b'secret-test-value',body)
        status,_,_=self.request('GET','/api/context/../../etc/passwd');self.assertEqual(status,400)
    def test_youtube_routing_is_not_claimed_complete(self):
        d=m.prepare_task('Estude https://youtu.be/abcdefghijk',state_root=Path(self.temp.name))
        self.assertEqual(d['procedure'],'youtube-reverse-engineering');self.assertEqual(d['status'],'prepared')

s2=importlib.util.spec_from_file_location('reverse_tests',R/'.agents/skills/youtube-reverse-engineering/scripts/test_reverse.py');rt=importlib.util.module_from_spec(s2);s2.loader.exec_module(rt)
ReverseTests=rt.ReverseTests
if __name__=='__main__':unittest.main()
