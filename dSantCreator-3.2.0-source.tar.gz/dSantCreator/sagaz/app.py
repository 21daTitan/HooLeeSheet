"""SagaZ: local blue console, built independently for dSantCreator."""
import argparse
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import importlib.util
import json
import os
from pathlib import Path
import secrets
import sys
import threading
from urllib.parse import urlparse
import uuid

ROOT=Path(__file__).resolve().parents[1]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

CORE=load('sagaz_creator',ROOT/'.agents/skills/dsant-creator/scripts/creator.py')


def prepare_task(brief,niche='general',method='cinematic-3d',use_model=False,state_root=None):
    if not isinstance(brief,str) or not 1<=len(brief.strip())<=6000:raise ValueError('Descreva a tarefa em até 6.000 caracteres.')
    if niche not in CORE.NICHES or method not in CORE.METHODS or not isinstance(use_model,bool):raise ValueError('Opções da tarefa inválidas.')
    directory=(Path(state_root) if state_root else ROOT/'projects/sagaz')/uuid.uuid4().hex
    result=CORE.prepare(argparse.Namespace(brief=brief.strip(),niche=niche,method=method,route='remotion',task=None,state_dir=None,out=str(directory)))
    cfg=CORE.read(directory/'campaign.json')
    if use_model:
        generated=CORE.run(directory)
        answer=Path(generated['output']).read_text(encoding='utf-8')
        mode='configured_model'
    else:
        mode='local_preparation'
        answer=(f"Tarefa preparada: {cfg['task']} · {niche}\n\n"
                f"Procedimento: {cfg['procedure']}\n"
                f"Método: {method} · Rota: {cfg['route']}\n\n"
                "Próximo passo: abrir o contexto no agente escolhido e executar o procedimento. "
                "O pacote inclui briefing, fontes e estudos parciais compatíveis.\n\n"
                "Modo local: nenhum modelo foi chamado; roteiro/copy/análise final ainda não foram gerados.")
    return dict(id=directory.name,answer=answer,mode=mode,task=cfg['task'],procedure=cfg['procedure'],sources=len(cfg['sources']),studies=cfg.get('studies',[]),status='text_generated' if use_model else 'prepared')


def research(url,state_root=None):
    reverse=load('sagaz_reverse',ROOT/'.agents/skills/youtube-reverse-engineering/scripts/reverse.py')
    url=reverse.canonical(url)
    directory=(Path(state_root) if state_root else ROOT/'projects/sagaz')/uuid.uuid4().hex
    result=reverse.acquire(url,directory)
    return dict(id=directory.name,**result)


class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,state_root=None):
        self.session=secrets.token_urlsafe(32)
        self.state_root=Path(state_root) if state_root else ROOT/'projects/sagaz'
        self.busy=threading.BoundedSemaphore(2)
        super().__init__(address,Handler)


class Handler(BaseHTTPRequestHandler):
    server_version='SagaZ/3.2'
    def log_message(self,*args):pass
    def valid_host(self):
        port=self.server.server_port
        return self.headers.get('Host') in (f'127.0.0.1:{port}',f'localhost:{port}')
    def send(self,status,data,kind='application/json; charset=utf-8',cookie=False):
        body=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False).encode()
        self.send_response(status);self.send_header('Content-Type',kind)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
        if cookie:self.send_header('Set-Cookie',f'sagaz_session={self.server.session}; HttpOnly; SameSite=Strict; Path=/')
        self.end_headers();self.wfile.write(body)
    def project(self,ident):
        if not isinstance(ident,str) or not (len(ident)==32 and all(c in '0123456789abcdef' for c in ident)):raise ValueError('ID inválido')
        path=self.server.state_root/ident
        if path.is_symlink():raise ValueError('Projeto inválido')
        return path
    def do_GET(self):
        if not self.valid_host():return self.send(421,{'error':'Host não permitido'})
        path=urlparse(self.path).path
        if path=='/':return self.send(200,(ROOT/'sagaz/index.html').read_bytes(),'text/html; charset=utf-8',cookie=True)
        if path=='/api/status':
            return self.send(200,{'name':'SagaZ','version':(ROOT/'VERSION').read_text().strip(),'model_configured':bool(os.environ.get('DSANT_BASE_URL') and os.environ.get('DSANT_MODEL')),'default_mode':'local_preparation','shell':False,'sources':len(CORE.registry()['entries'])})
        if path=='/api/integrations':return self.send(200,json.loads((ROOT/'knowledge/integrations.json').read_text(encoding='utf-8')))
        if path=='/api/sources':return self.send(200,CORE.registry())
        if path=='/api/projects':
            rows=[]
            for folder in sorted(self.server.state_root.glob('*'),key=lambda p:p.name):
                if folder.is_symlink():continue
                if (folder/'campaign.json').is_file():
                    try:
                        cfg=CORE.read(folder/'campaign.json');rows.append(dict(id=folder.name,brief=cfg['brief'],niche=cfg['niche'],task=cfg['task'],created_at=cfg['created_at']))
                    except (ValueError,OSError,KeyError):continue
            return self.send(200,rows)
        if path.startswith('/api/context/'):
            try:
                file=self.project(path.split('/')[-1])/'context.md'
                if not file.is_file():return self.send(404,{'error':'Contexto não encontrado'})
                return self.send(200,file.read_bytes(),'text/markdown; charset=utf-8')
            except ValueError:return self.send(400,{'error':'Projeto inválido'})
        return self.send(404,{'error':'Rota não encontrada'})
    def do_POST(self):
        if not self.valid_host():return self.send(421,{'error':'Host não permitido'})
        origin=self.headers.get('Origin')
        if origin and origin!='http://'+self.headers.get('Host',''):return self.send(403,{'error':'Origem não permitida'})
        cookie=SimpleCookie()
        try:cookie.load(self.headers.get('Cookie',''))
        except Exception:return self.send(403,{'error':'Sessão inválida'})
        value=cookie.get('sagaz_session')
        if not value or not hmac.compare_digest(value.value,self.server.session):return self.send(403,{'error':'Abra a interface local para iniciar a sessão'})
        if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.send(415,{'error':'JSON obrigatório'})
        try:length=int(self.headers.get('Content-Length','0'))
        except ValueError:return self.send(400,{'error':'Tamanho inválido'})
        if not 1<=length<=32768:return self.send(413,{'error':'Pedido excede o limite'})
        if not self.server.busy.acquire(blocking=False):return self.send(429,{'error':'Duas tarefas em andamento; tente novamente após terminar'})
        try:
            data=json.loads(self.rfile.read(length))
            if not isinstance(data,dict):raise ValueError('Corpo JSON inválido')
            if self.path=='/api/chat':
                result=prepare_task(data.get('brief'),data.get('niche','general'),data.get('method','cinematic-3d'),data.get('use_model',False),self.server.state_root)
            elif self.path=='/api/research':result=research(data.get('url',''),self.server.state_root)
            else:return self.send(404,{'error':'Rota não encontrada'})
            return self.send(200,result)
        except (ValueError,TypeError,KeyError) as exc:return self.send(400,{'error':str(exc)})
        except Exception as exc:return self.send(500,{'error':'Falha em '+type(exc).__name__+'; confira configuração e arquivos locais'})
        finally:self.server.busy.release()


def serve(port=8080,state_root=None):
    with Server(('127.0.0.1',port),state_root) as server:
        print(f'SagaZ · http://127.0.0.1:{server.server_port} · modo local por padrão',flush=True)
        try:server.serve_forever()
        except KeyboardInterrupt:pass


def cli(use_model=False):
    blue='\033[38;5;39m' if sys.stdout.isatty() else ''
    reset='\033[0m' if blue else ''
    print(blue+'SagaZ · Console azul · digite sair para encerrar'+reset)
    while True:
        try:brief=input(blue+'SagaZ > '+reset).strip()
        except (EOFError,KeyboardInterrupt):break
        if brief.casefold() in ('sair','exit','quit'):break
        if not brief:continue
        try:print(prepare_task(brief,use_model=use_model)['answer'])
        except (ValueError,OSError) as exc:print('Erro:',exc)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--web',action='store_true');parser.add_argument('--port',type=int,default=8080);parser.add_argument('--use-model',action='store_true');a=parser.parse_args()
    serve(a.port) if a.web else cli(a.use_model)
