# Validação — versão 3.2.0 / 04/11/2026

## Executado nesta entrega

- 25 testes offline aprovados em Python 3.12.14/Linux.
- Instalação temporária para os três agentes, idempotência, conflito/edições, backups e atualização Git local.
- Contratos e isolamento entre nichos, histórico, URL e transporte de API simulado.
- Legendas autorais VTT/JSON3; entrada local sem URL; dossiê rascunho e barreiras de revisão; cortes recusados sem evidência visual; notas não finitas recusadas.
- Teste independente de análise de legenda de 10 s: resultado editorial com evidência textual; validador passou com URL ausente preservada. Média/cobertura são editoriais, não desempenho.
- API SagaZ real em loopback dentro dos testes: preparação sem modelo, exportação de contexto, listagem, rejeição de origem/host/sessão inválidos e ausência de chave na resposta.
- Sintaxe Python no pacote e JavaScript da interface verificadas.
- Templates MIT de Claude Animated Shorts copiados com licença/origem, sem frames de estudo de terceiros.
- Configuração do pacote para seis skills e interface azul/Matrix local.

## Limites observados

O browser de preview deste ambiente não conseguiu acessar o servidor local; não há revisão visual da interface por navegador. Testes HTTP não substituem essa revisão. Nenhum endpoint real de modelo, ASR, geração de voz ou render multimídia foi executado nesta versão. Os novos templates foram integrados como fonte técnica, sem build/render final.

Doctor nesta sessão detectou Git, FFmpeg, FFprobe, Node/npm e Blender. cv2, SceneDetect, faster-whisper e yt-dlp não estavam no Python ativo. A nova coleta fornece modo degradado e aceita arquivos locais; instalar o perfil multimídia é decisão do ambiente do usuário. A validação não instala recursos no seu PC/VPS.

## Evidência herdada

O analisador havia processado um MP4 APVS local com quadros/metadados/áudio, sem ASR. A playlist conserva 15 estudos por amostragem e uma entrada indisponível reportada. Não houve nova revisão integral de todas as aulas ou dos demais vídeos enviados.

## Publicação e conexões

A conexão GitHub do usuário continua sem instalação com escrita disponível. O upload para 21daTitan/HooLeeSheet permanece pendente. Não há teste real no Windows, Termux, Claude Code/OpenCode, nem conexão à VPS/9Router. Nenhum modelo pesado, sessão social ou serviço pago foi ativado.
