# HooLeeSheet- · dSantCreator

Agente portátil de criação: copy, CTA, ofertas, estratégia, referências e produção audiovisual. Reaproveita seu modelo e suas ferramentas; o núcleo funciona sem pip e sem chave de API. Recursos locais vêm primeiro, serviços pagos entram somente por decisão do usuário.

## SagaZ azul / Matrix

```bash
python dsant.py sagaz --web
```

Abra `http://127.0.0.1:8080`. O console prepara tarefas sem API; geração textual pelo endpoint é opcional e explicitamente selecionada. Projetos/contextos ficam fora do Git. Esta é uma implementação independente, não uma cópia redistribuída da Cassandra. Ver [SagaZ](docs/SAGAZ.md).

## Engenharia reversa YouTube

```bash
python dsant.py youtube acquire 'https://youtu.be/ID_DO_VIDEO' --out projects/estudo-001
# Ou evidência própria sem URL:
python dsant.py youtube acquire --transcript minha-legenda.vtt --out projects/estudo-local
python dsant.py youtube validate projects/estudo-local/dossier.json
```

Para coleta online de legendas, instale apenas `yt-dlp` em um venv; transcrição ASR e vídeo são opcionais e usam o perfil de mídia. Sem rede, forneça sua legenda local.

O coletor cria evidências e um dossiê em rascunho. O agente analisa a evidência para preencher o gabarito/macete; validar JSON não prova qualidade da análise. Cortes, câmera e som precisam de evidências próprias. Nenhuma previsão de CTR ou viralização é inventada.

[Estado dos 11 projetos indicados](docs/INTEGRATIONS.md): Three.js nos templates; templates MIT de Claude Animated Shorts incorporados; ferramentas pesadas ou pagas registradas como opcionais, sem instalação automática.

## Instalação

Requisitos básicos: Git e Python 3.10+. No Windows, usar `py -3` se `python` não existir. No Android, preferir acessar sua VPS por SSH; Termux pode ter limitações em dependências de transcrição.

```bash
git clone https://github.com/21daTitan/HooLeeSheet.git dSantCreator
cd dSantCreator
python dsant.py install --target all
python dsant.py doctor
```

O instalador copia as skills para os diretórios do usuário de Codex, Claude Code e OpenCode. Não instala esses aplicativos nem seus modelos. Escolha um alvo com `--target claude`, `codex` ou `opencode`. Para núcleo de copy/estratégia e análise textual: acrescente `--profile core`. Padrão: `media`, com todas as seis skills. O próprio clone já contém skills em `.agents/skills/` para agentes que reconhecem esse caminho.

Não substitui pastas de terceiros. Recusa alterações manuais nas cópias instaladas; preserve/mova suas edições antes de atualizar. Quando troca uma versão gerenciada, mantém backup da anterior. Campanhas e chaves ficam separadas.

## Compatibilidade

| Ambiente | Uso | Limite |
|---|---|---|
| Claude Code | Skills em `~/.claude/skills/`, instruções em `CLAUDE.md` | Permissões, modelo e ferramentas da sessão |
| OpenCode | Skills em `~/.config/opencode/skills/` ou `.agents/skills/` | Provedor/modelo escolhido pelo usuário |
| Codex local | `.agents/skills/` e `AGENTS.md` | Ferramentas e permissões do executor |
| ChatGPT Plus / Work | Pacote de contexto; skills nativas quando a conta/interface oferecer | Upload de contexto não instala um serviço; conferir recursos da sessão |
| Claude no navegador | Pacote de contexto/arquivo do projeto; skills se disponíveis na conta | Execução e integrações dependem da interface |
| Outros chats | Markdown portátil | Sem promessa de executar scripts ou atualizar sozinho |

Formatos/diretórios baseados na [documentação OpenAI](https://learn.chatgpt.com/docs/build-skills), [Claude Code](https://code.claude.com/docs/en/skills) e [OpenCode](https://opencode.ai/docs/skills/), consultadas em 04/11/2026. Compatibilidade do pacote não significa testes dentro de todos os aplicativos.

## ChatGPT Plus e Claude web

```bash
python dsant.py pack
```

Você também pode baixar o [pack já incluído](portable/dSantCreator-context.md) sem usar terminal.

Anexe `exports/dSantCreator-context.md` ao seu projeto/conversa e envie seu briefing. O pack padrão exclui estudos hot. Para um projeto adulto não explícito e separado, use `python dsant.py pack --niche hot --out exports/dSantCreator-hot.md`. Nenhum pack contém chave de API.

Após atualizar o repositório, gere um novo pack com outro nome e substitua o arquivo no aplicativo. Chats web não acompanham automaticamente alterações no GitHub. No ChatGPT Work com skills, a importação/atualização segue os controles da própria interface; o instalador local não altera a conta remota.

## Uso

Peça ao agente:

```text
Use dsant-creator: crie uma campanha da RR Eletrônica sobre painel apagado,
com três ganchos, roteiro POV e CTA para avaliação. Sinalize dados faltantes.
```

Ou prepare contrato/contexto pelo terminal:

```bash
python dsant.py agent prepare --brief 'Campanha RR: painel apagado' --niche automotive --method automotive-pov --out projects/rr-001
python dsant.py agent validate projects/rr-001
python dsant.py agent refs --tag copywriting --scope all
```

Prepare cria contrato/contexto; não gera vídeo. O agente do aplicativo utiliza esses arquivos para executar a tarefa. Atualizar fontes usa `agent refs-add URL --title TITULO --tags copywriting cta --scope generic --state-dir state`; usar o mesmo `--state-dir state` em `prepare`/`refs` para consumir o catálogo atualizado.

`agent run PASTA` é opcional e chama somente endpoint compatível com chat completions configurado no ambiente. Não assume acesso pela assinatura Plus/Claude nem compra créditos. Sem endpoint, continue pelo chat. Ver `.env.example`; esse arquivo não é carregado automaticamente.

## Mídia opcional

```bash
python -m venv .venv
# Linux/macOS/VPS:
. .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-media.txt
python dsant.py doctor
```

FFmpeg/FFprobe devem estar no PATH; Node/npm são usados nos templates Remotion. Use o gerenciador oficial do seu sistema. Dependências Python são isoladas no venv; não alteramos políticas de execução do Windows. faster-whisper pode baixar um modelo na primeira execução. Renderizadores precisam das dependências dos respectivos templates; não são instalados pelo núcleo.

As skills de mídia incluem fontes/templates, não todos os arquivos de voz, fontes tipográficas e assets externos. Ler a skill antes de adaptar e executar. Google Flow é opcional e sujeito à conta/limites do usuário. Nenhuma ferramenta paga é chamada por padrão.

O pacote `.tar.gz` também roda após extrair, sem instalação global. O comando de atualização por Git exige um clone com `.git`; o arquivo compactado não contém histórico.

## Atualizações

```bash
python dsant.py update --target all
```

Faz `git pull --ff-only` e reinstala as skills gerenciadas. Não faz reset, não usa force e não sobrescreve edições rastreadas. Use os mesmos alvo/perfil da instalação. Em fork ou clone editado, faça sua revisão/merge manual e depois rode `install`. Atualizar muda código que será executado; confira as alterações quando necessário. Não há serviço de atualização em segundo plano.

## Skills incluídas

| Skill | Função |
|---|---|
| dsant-creator | Coordenação, copy, CTA, estratégia, fontes e contratos |
| dsant-creator-cartoon | Narrativa, continuidade, 3D cinematográfico e automotivo/POV |
| remotion-problem-resolve-video | Explicações técnicas problema → solução |
| tiktok-storyboard-analyzer | Evidências, imagens-base, movimento e transcrição |
| ponytail | Implementação pequena e verificável |
| youtube-reverse-engineering | Evidências, gabarito, macete e avaliação editorial |

## Validação e limites

```bash
python -m unittest discover -s tests -v
```

Os testes verificam instalação, conflitos, preservação, atualização com Git local, exportação sem hot por padrão e contratos do núcleo. Não comprovam qualidade criativa, elegibilidade de plataforma ou retorno financeiro. [VALIDATION.md](docs/VALIDATION.md) registra o que foi executado nesta entrega.

A [playlist Formação NGB](knowledge/playlists/PLBPobzL8BYoHZPSfnfrPR02eE5Xb4JeLi/README.md) está integrada com 15 estudos parciais, índice por aula, divergências e recuperação de até três notas relevantes em cada `prepare`/pack. Não foi promovida a estudo integral.

Catálogo: referências por escopo, com evidência e estado. Metadados de 15 aulas da playlist foram acessíveis em 04/11/2026; os estudos herdados são parciais. Uma entrada foi reportada indisponível. Aprendizado é registro consultável, não treinamento automático do modelo. Nunca fabricar prova, escassez, depoimento, métrica ou identidade para converter.

Ver [custos e evolução](docs/COSTS.md) e [origens e direitos](THIRD_PARTY_NOTICES.md). Não há garantia de execução de todas as etapas em qualquer dispositivo; o agente deve diagnosticar e entregar a melhor rota disponível com limites explícitos.
